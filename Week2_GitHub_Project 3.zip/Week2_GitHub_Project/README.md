# AI-Assisted Dialysis Monitoring — Architecture Proposal

## Overview
This repository contains an educational architecture blueprint for an AI-assisted monitoring workflow in a dialysis-centre setting. It demonstrates proposed data sources, integration, validation, AI inference, clinician review, security, monitoring and risk controls.

## Important limitation
This is a conceptual student project, not a validated clinical system or medical device. It must not be used to make patient-care decisions. The proposed AI is advisory only and does not control dialysis equipment or prescribe treatment.

## Contents
- `docs/Week2_Healthcare_AI_Architecture_Blueprint.docx` — full report
- `diagrams/architecture.png` — system architecture diagram
- `diagrams/dataflow.png` — data-flow diagram
- `tests/test-plan.md` — sample safety and integration test ideas
- `data/sample_synthetic_observations.csv` — artificial data only

## Standards and governance
The report discusses HL7 FHIR as a candidate interoperability standard where supported by the target EHR, WHO guidance on ethics and governance of AI for health, and relevant Indian digital-health privacy policy context. A real implementation requires site-specific clinical, privacy, cybersecurity and regulatory review.

## No patient data
No real patient information, credentials, private keys, or production system access should be added to this repository.
