# Example Test Plan (Synthetic Data Only)

1. Valid observation: accepted with source, unit, patient/session reference and timestamps retained.
2. Missing critical value: flagged as incomplete; AI output suppressed if the field is required.
3. Invalid unit: rejected or quarantined rather than silently converted.
4. Duplicate message: detected and handled idempotently.
5. Stale observation: dashboard clearly indicates staleness; no current-looking alert is shown.
6. Patient/session mismatch: quarantined and logged.
7. Integration outage: dashboard reports AI service unavailable and directs staff to normal workflow.
8. Unauthorised user: access denied and security event logged.
9. Model version change: version recorded and regression tests required before release.
10. Clinician override: action and rationale recorded according to local policy.

These are design-level test ideas, not evidence of clinical validation.
